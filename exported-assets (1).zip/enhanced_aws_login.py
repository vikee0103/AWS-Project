# Enhanced AWS Portal Client with fixes
import boto3
from botocore.config import Config as botoConfig
from datetime import datetime
import urllib3
import getpass
import json
from botocore.exceptions import ClientError

http = urllib3.PoolManager()

### CUSTOM EXCEPTIONS ###

class AWSPortalLoginError(Exception):
    def __init__(self, *errData):
        super().__init__(*errData)
        self.errData = errData

    def __str__(self):
        return str(self.errData)

class AWSAccountIdError(Exception):
    def __init__(self, *errData):
        super().__init__(*errData)
        self.errData = errData

    def __str__(self):
        return str(self.errData)

# Exceptions: Proxy connection failed
AWSConnectionError = ClientError
# Exceptions: AWS Credentials expired
AWSCredentialsError = ClientError

### CLIENT CLASS ###
class AWSPortalClient:
    """
    Gets credentials and then builds boto3 client
    """
    def __init__(self, username: str, password: str):
        self.proxy_host = 'primary-proxy.gslb.intranet.barcapint.com'
        self.proxy_port = '8080'

        # Store user's credentials for later http calls
        self.username = username
        self.password = password

        # Initialize http connection pool manager
        self.http = urllib3.PoolManager()

        # Build the proxy auth strings
        self.proxies = {'https': f'https://{self.username}:{self.password}@{self.proxy_host}:{self.proxy_port}'}

    def gather_token(self):
        """
        Contacts the AWS portal, exchanges credentials for a session token
        """
        tokenUrl = "https://awsportal.barcapint.com/v1/jwttoken"
        tokenBody = json.dumps({"username": self.username, "password": self.password})
        tokenResponse = self.http.request("POST", tokenUrl, body=tokenBody)
        if tokenResponse.status != 200:
            raise AWSPortalLoginError("Incorrect username or password")
        print("[INFO] Logged In")
        return json.loads(tokenResponse.data.decode("utf-8"))["token"]

    def list_accounts(self, token):
        """
        Gets all the AWS account IDs the user has
        """
        rolesUrl = "https://awsportal.barcapint.com/v1/creds-provider/roles?size=200"
        rolesHeaders = {"authorization": "Bearer " + token}
        rolesResponse = self.http.request("GET", rolesUrl, headers=rolesHeaders)
        rolesList = json.loads(rolesResponse.data.decode('utf-8'))["items"]

        for item in rolesList:
            print(item["account_id"])

    def gather_credentials(self, token, accountId):
        """
        Given a valid token and an AWS account ID, fetch the temporary AWS credentials
        """
        try:
            # Gathers credentials from AWS Portal
            rolesUrl = "https://awsportal.barcapint.com/v1/creds-provider/roles?size=200"
            rolesHeaders = {"authorization": "Bearer " + token}
            rolesResponse = self.http.request("GET", rolesUrl, headers=rolesHeaders)
            rolesList = json.loads(rolesResponse.data.decode('utf-8'))["items"]

            for i in rolesList:
                if i["account_id"] == accountId:
                    roleArn = i["role_arn"]
                    break
            else:
                raise AWSAccountIdError("[WARN] Account Not Found")

            credentialsUrl = 'https://awsportal.barcapint.com/v1/creds-provider/provide-credentials/' + roleArn
            credentialsHeaders = {"authorization": "Bearer " + token}
            credentialsResponse = self.http.request("GET", credentialsUrl, headers=credentialsHeaders)
            return json.loads(credentialsResponse.data.decode('utf-8'))["Credentials"]

        except AWSAccountIdError:
            print("[WARN] AWS account invalid or not provided")
            return None

    def create_client(self, credentials, service, region):
        """
        Take AWS temp credentials and desired AWS service and region and spins up a boto3 client ready to call AWS
        """
        try:
            # Attempts to create a session
            session = boto3.Session(
                region_name=region,
                aws_secret_access_key=credentials["SecretAccessKey"],
                aws_access_key_id=credentials["AccessKeyId"],
                aws_session_token=credentials["SessionToken"]
            )
            client = session.client(service, config=botoConfig(proxies=self.proxies))
            print("[INFO] Credentials Accepted")
            return client

        except AWSConnectionError:
            print("[WARN] Connection Error, check internet connection / proxy connection and try again")
            return None

        except AWSCredentialsError:
            print("[WARN] AWS Credentials Error, check user / AWS account and try again")
            return None

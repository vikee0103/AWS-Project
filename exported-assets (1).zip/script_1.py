# Create the main Streamlit application
streamlit_app_code = '''import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import json
import sqlite3
import io
from datetime import datetime
import re
from enhanced_aws_login import AWSPortalClient
import numpy as np

# Page configuration
st.set_page_config(
    page_title="NLP to SQL Analytics Platform",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for better styling
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        color: #1f77b4;
        text-align: center;
        margin-bottom: 2rem;
        font-weight: bold;
    }
    .sub-header {
        font-size: 1.5rem;
        color: #2c3e50;
        margin-bottom: 1rem;
    }
    .info-box {
        background-color: #f0f2f6;
        padding: 1rem;
        border-radius: 0.5rem;
        margin: 1rem 0;
    }
    .success-box {
        background-color: #d4edda;
        padding: 1rem;
        border-radius: 0.5rem;
        border-left: 4px solid #28a745;
        margin: 1rem 0;
    }
    .error-box {
        background-color: #f8d7da;
        padding: 1rem;
        border-radius: 0.5rem;
        border-left: 4px solid #dc3545;
        margin: 1rem 0;
    }
</style>
""", unsafe_allow_html=True)

# Initialize session state
def initialize_session_state():
    if 'authenticated' not in st.session_state:
        st.session_state.authenticated = False
    if 'aws_client' not in st.session_state:
        st.session_state.aws_client = None
    if 'bedrock_client' not in st.session_state:
        st.session_state.bedrock_client = None
    if 'uploaded_data' not in st.session_state:
        st.session_state.uploaded_data = None
    if 'sql_query' not in st.session_state:
        st.session_state.sql_query = ""
    if 'query_result' not in st.session_state:
        st.session_state.query_result = None

# Function to authenticate AWS
def authenticate_aws(username, password, account_id, region):
    try:
        with st.spinner("Authenticating with AWS..."):
            aws_client = AWSPortalClient(username=username, password=password)
            token = aws_client.gather_token()
            credentials = aws_client.gather_credentials(token, account_id)
            
            if credentials:
                bedrock_client = aws_client.create_client(credentials, 'bedrock-runtime', region)
                if bedrock_client:
                    st.session_state.aws_client = aws_client
                    st.session_state.bedrock_client = bedrock_client
                    st.session_state.authenticated = True
                    return True
        return False
    except Exception as e:
        st.error(f"Authentication failed: {str(e)}")
        return False

# Function to generate SQL using AWS Bedrock
def generate_sql_with_bedrock(natural_language_query, table_schema, bedrock_client):
    try:
        # Create a comprehensive prompt for SQL generation
        prompt = f"""
        You are an expert SQL developer. Given the following table schema and natural language query, 
        generate a precise SQL query that answers the question.
        
        Table Schema:
        {table_schema}
        
        Natural Language Query: {natural_language_query}
        
        Instructions:
        1. Generate only valid SQL syntax
        2. Use appropriate WHERE clauses, JOINs, GROUP BY, ORDER BY as needed
        3. The table name is 'data_table'
        4. Return only the SQL query without any explanation
        5. Ensure the query is optimized and follows best practices
        
        SQL Query:
        """
        
        # Prepare the message for Bedrock
        message = [{"role": "user", "content": [{"text": prompt}]}]
        model_id = 'anthropic.claude-3-sonnet-20240620-v1:0'
        
        # Call Bedrock
        response = bedrock_client.converse(modelId=model_id, messages=message)
        
        # Extract the SQL query
        output_text = response['output']['message']
        sql_query = ''
        for content in output_text['content']:
            sql_query += content['text']
            
        # Clean up the SQL query
        sql_query = sql_query.strip()
        # Remove any markdown formatting
        sql_query = re.sub(r'```sql', '', sql_query)
        sql_query = re.sub(r'```', '', sql_query)
        sql_query = sql_query.strip()
        
        return sql_query
        
    except Exception as e:
        st.error(f"Error generating SQL: {str(e)}")
        return None

# Function to execute SQL query on uploaded data
def execute_sql_query(sql_query, dataframe):
    try:
        # Create an in-memory SQLite database
        conn = sqlite3.connect(':memory:')
        
        # Load dataframe into SQLite
        dataframe.to_sql('data_table', conn, index=False, if_exists='replace')
        
        # Execute the SQL query
        result = pd.read_sql_query(sql_query, conn)
        
        conn.close()
        return result
        
    except Exception as e:
        st.error(f"Error executing SQL query: {str(e)}")
        return None

# Function to create visualizations
def create_visualizations(data, query_description):
    """Create various charts based on the data"""
    if data is None or data.empty:
        return None
        
    charts = []
    
    # Determine chart types based on data
    numeric_cols = data.select_dtypes(include=[np.number]).columns.tolist()
    categorical_cols = data.select_dtypes(include=['object', 'category']).columns.tolist()
    
    # Chart 1: Bar chart if we have categorical and numeric data
    if len(categorical_cols) >= 1 and len(numeric_cols) >= 1:
        fig_bar = px.bar(
            data, 
            x=categorical_cols[0], 
            y=numeric_cols[0],
            title=f"Bar Chart: {categorical_cols[0]} vs {numeric_cols[0]}",
            color=categorical_cols[0] if len(data) < 50 else None
        )
        fig_bar.update_layout(showlegend=len(data) < 20)
        charts.append(("Bar Chart", fig_bar))
    
    # Chart 2: Line chart for time series or numeric progression
    if len(numeric_cols) >= 2:
        fig_line = px.line(
            data, 
            x=data.columns[0], 
            y=numeric_cols[0],
            title=f"Line Chart: {data.columns[0]} vs {numeric_cols[0]}"
        )
        charts.append(("Line Chart", fig_line))
    
    # Chart 3: Pie chart for categorical data with counts
    if len(categorical_cols) >= 1 and len(data) <= 20:
        value_counts = data[categorical_cols[0]].value_counts()
        fig_pie = px.pie(
            values=value_counts.values,
            names=value_counts.index,
            title=f"Distribution of {categorical_cols[0]}"
        )
        charts.append(("Pie Chart", fig_pie))
    
    # Chart 4: Scatter plot for two numeric variables
    if len(numeric_cols) >= 2:
        fig_scatter = px.scatter(
            data,
            x=numeric_cols[0],
            y=numeric_cols[1],
            title=f"Scatter Plot: {numeric_cols[0]} vs {numeric_cols[1]}",
            color=categorical_cols[0] if categorical_cols else None
        )
        charts.append(("Scatter Plot", fig_scatter))
    
    return charts

# Main application
def main():
    initialize_session_state()
    
    # Header
    st.markdown('<h1 class="main-header">🔍 NLP to SQL Analytics Platform</h1>', unsafe_allow_html=True)
    
    # Sidebar for configuration
    with st.sidebar:
        st.markdown('<h2 class="sub-header">⚙️ Configuration</h2>', unsafe_allow_html=True)
        
        # AWS Authentication section
        if not st.session_state.authenticated:
            st.markdown("### 🔐 AWS Authentication")
            
            with st.form("aws_auth"):
                username = st.text_input("Username", placeholder="Enter your username")
                password = st.text_input("Password", type="password", placeholder="Enter your password")
                account_id = st.text_input("AWS Account ID", placeholder="Enter AWS Account ID")
                region = st.selectbox("AWS Region", ["us-east-1", "us-west-2", "eu-west-1", "ap-southeast-1"])
                
                if st.form_submit_button("🚀 Authenticate", type="primary"):
                    if username and password and account_id:
                        if authenticate_aws(username, password, account_id, region):
                            st.success("✅ Authentication successful!")
                            st.rerun()
                        else:
                            st.error("❌ Authentication failed!")
                    else:
                        st.error("Please fill in all fields")
        else:
            st.success("✅ AWS Authenticated")
            if st.button("🔓 Logout"):
                st.session_state.authenticated = False
                st.session_state.aws_client = None
                st.session_state.bedrock_client = None
                st.rerun()
    
    # Main content area
    if st.session_state.authenticated:
        
        # File upload section
        st.markdown('<h2 class="sub-header">📁 Data Upload</h2>', unsafe_allow_html=True)
        
        uploaded_file = st.file_uploader(
            "Upload your Excel file",
            type=['xlsx', 'xls', 'csv'],
            help="Upload an Excel or CSV file to analyze"
        )
        
        if uploaded_file is not None:
            try:
                # Read the uploaded file
                if uploaded_file.name.endswith('.csv'):
                    df = pd.read_csv(uploaded_file)
                else:
                    df = pd.read_excel(uploaded_file)
                
                st.session_state.uploaded_data = df
                
                # Display file info and preview
                col1, col2, col3 = st.columns(3)
                with col1:
                    st.metric("Rows", len(df))
                with col2:
                    st.metric("Columns", len(df.columns))
                with col3:
                    st.metric("File Size", f"{uploaded_file.size / 1024:.1f} KB")
                
                # Data preview
                st.markdown("### 👀 Data Preview")
                st.dataframe(df.head(10), use_container_width=True)
                
                # Show data types and basic statistics
                with st.expander("📊 Data Information"):
                    col1, col2 = st.columns(2)
                    
                    with col1:
                        st.markdown("**Column Data Types:**")
                        st.write(df.dtypes.to_frame('Data Type'))
                    
                    with col2:
                        st.markdown("**Basic Statistics:**")
                        st.write(df.describe())
                
            except Exception as e:
                st.error(f"Error reading file: {str(e)}")
        
        # NLP to SQL section
        if st.session_state.uploaded_data is not None:
            st.markdown('<h2 class="sub-header">🤖 Natural Language to SQL</h2>', unsafe_allow_html=True)
            
            # Create table schema description
            df = st.session_state.uploaded_data
            schema_description = f"Table 'data_table' has {len(df.columns)} columns: "
            schema_description += ", ".join([f"{col} ({df[col].dtype})" for col in df.columns])
            
            # Natural language query input
            natural_query = st.text_area(
                "Describe what you want to analyze in plain English:",
                placeholder="Example: Show me the top 5 products by sales amount, or Find the average age by department",
                height=100
            )
            
            if st.button("🔮 Generate SQL Query", type="primary"):
                if natural_query:
                    with st.spinner("Generating SQL query..."):
                        sql_query = generate_sql_with_bedrock(
                            natural_query, 
                            schema_description, 
                            st.session_state.bedrock_client
                        )
                        
                        if sql_query:
                            st.session_state.sql_query = sql_query
                            st.success("✅ SQL query generated successfully!")
                        else:
                            st.error("❌ Failed to generate SQL query")
                else:
                    st.error("Please enter a natural language query")
            
            # Display and allow editing of SQL query
            if st.session_state.sql_query:
                st.markdown("### 📝 Generated SQL Query")
                edited_query = st.text_area(
                    "SQL Query (you can edit if needed):",
                    value=st.session_state.sql_query,
                    height=150
                )
                
                if st.button("▶️ Execute Query", type="primary"):
                    with st.spinner("Executing query..."):
                        result = execute_sql_query(edited_query, df)
                        
                        if result is not None:
                            st.session_state.query_result = result
                            st.success(f"✅ Query executed successfully! Found {len(result)} rows.")
                        else:
                            st.error("❌ Query execution failed")
        
        # Results display section
        if st.session_state.query_result is not None:
            st.markdown('<h2 class="sub-header">📈 Query Results</h2>', unsafe_allow_html=True)
            
            result_data = st.session_state.query_result
            
            # Results tabs
            tab1, tab2, tab3 = st.tabs(["📋 Table View", "📊 Charts", "📥 Export"])
            
            with tab1:
                st.markdown("### Table Results")
                st.dataframe(result_data, use_container_width=True)
                
                # Show summary statistics
                if len(result_data) > 0:
                    st.markdown("### Summary Statistics")
                    numeric_cols = result_data.select_dtypes(include=[np.number]).columns
                    if len(numeric_cols) > 0:
                        st.dataframe(result_data[numeric_cols].describe(), use_container_width=True)
            
            with tab2:
                st.markdown("### Data Visualizations")
                
                charts = create_visualizations(result_data, natural_query if 'natural_query' in locals() else "")
                
                if charts:
                    # Display charts in a grid
                    for i in range(0, len(charts), 2):
                        cols = st.columns(2)
                        for j, col in enumerate(cols):
                            if i + j < len(charts):
                                with col:
                                    chart_name, chart_fig = charts[i + j]
                                    st.plotly_chart(chart_fig, use_container_width=True)
                else:
                    st.info("No suitable visualizations could be created for this data.")
            
            with tab3:
                st.markdown("### Export Results")
                
                # Export to different formats
                col1, col2, col3 = st.columns(3)
                
                with col1:
                    csv_data = result_data.to_csv(index=False)
                    st.download_button(
                        label="📥 Download as CSV",
                        data=csv_data,
                        file_name=f"query_results_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                        mime="text/csv"
                    )
                
                with col2:
                    # Convert to Excel
                    output = io.BytesIO()
                    with pd.ExcelWriter(output, engine='openpyxl') as writer:
                        result_data.to_excel(writer, sheet_name='Results', index=False)
                    excel_data = output.getvalue()
                    
                    st.download_button(
                        label="📥 Download as Excel",
                        data=excel_data,
                        file_name=f"query_results_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx",
                        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                    )
                
                with col3:
                    json_data = result_data.to_json(orient='records', indent=2)
                    st.download_button(
                        label="📥 Download as JSON",
                        data=json_data,
                        file_name=f"query_results_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
                        mime="application/json"
                    )
    
    else:
        # Landing page for non-authenticated users
        st.markdown("""
        <div class="info-box">
            <h3>🎯 Welcome to the NLP to SQL Analytics Platform!</h3>
            <p>This powerful application allows you to:</p>
            <ul>
                <li>📊 Upload Excel/CSV files for analysis</li>
                <li>🤖 Convert natural language questions to SQL queries using AI</li>
                <li>📈 Visualize your data with interactive charts</li>
                <li>📥 Export results in multiple formats</li>
            </ul>
            <p><strong>👈 Please authenticate with your AWS credentials in the sidebar to get started.</strong></p>
        </div>
        """, unsafe_allow_html=True)
        
        # Feature showcase
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.markdown("""
            ### 🔐 Secure Authentication
            - Enterprise-grade AWS authentication
            - Secure credential handling
            - Session management
            """)
        
        with col2:
            st.markdown("""
            ### 🤖 AI-Powered Analysis
            - Natural language to SQL conversion
            - AWS Bedrock integration
            - Intelligent query generation
            """)
        
        with col3:
            st.markdown("""
            ### 📊 Rich Visualizations
            - Interactive charts and graphs
            - Multiple export formats
            - Professional reporting
            """)

if __name__ == "__main__":
    main()
'''

# Save the main Streamlit application
with open('nlp_sql_app.py', 'w') as f:
    f.write(streamlit_app_code)

print("Main Streamlit application created successfully!")
print("Files created:")
print("1. enhanced_aws_login.py - Enhanced AWS authentication module")
print("2. nlp_sql_app.py - Main Streamlit application")
# Create requirements.txt file
requirements_content = '''# Core Streamlit and Web Framework
streamlit>=1.28.0
pandas>=1.5.0
numpy>=1.24.0

# Data Visualization
plotly>=5.15.0
matplotlib>=3.7.0
seaborn>=0.12.0

# AWS Integration
boto3>=1.28.0
botocore>=1.31.0

# HTTP and Networking
urllib3>=1.26.0
requests>=2.31.0

# Data Processing and File Handling
openpyxl>=3.1.0
xlrd>=2.0.0
xlsxwriter>=3.1.0

# Database Support
sqlite3  # Built-in with Python
sqlalchemy>=2.0.0

# Utility Libraries
python-dateutil>=2.8.0
pytz>=2023.3

# Optional: Enhanced functionality
python-dotenv>=1.0.0  # For environment variables
'''

# Save requirements.txt
with open('requirements.txt', 'w') as f:
    f.write(requirements_content)

# Create a comprehensive README.md
readme_content = '''# NLP to SQL Analytics Platform

A powerful Python-based Streamlit application that converts natural language queries into SQL and provides rich data visualization capabilities using AWS Bedrock.

## 🚀 Features

- **🔐 Secure AWS Authentication**: Enterprise-grade authentication using AWS Portal
- **📊 Excel/CSV File Upload**: Easy drag-and-drop file upload functionality
- **🤖 AI-Powered NLP to SQL**: Convert natural language questions to SQL queries using AWS Bedrock
- **📈 Interactive Visualizations**: Generate charts and graphs automatically
- **📥 Multi-format Export**: Export results as CSV, Excel, or JSON
- **💻 Professional UI**: Clean, modern interface built with Streamlit

## 📋 Prerequisites

- Python 3.8 or higher
- AWS account with Bedrock access
- Valid AWS credentials and account ID
- Internet connection for AWS services

## 🛠️ Installation

1. **Clone or download the application files:**
   ```bash
   # Ensure you have these files:
   # - nlp_sql_app.py
   # - enhanced_aws_login.py
   # - requirements.txt
   ```

2. **Install required packages:**
   ```bash
   pip install -r requirements.txt
   ```

3. **Verify Streamlit installation:**
   ```bash
   streamlit --version
   ```

## 🚀 Running the Application

1. **Start the Streamlit application:**
   ```bash
   streamlit run nlp_sql_app.py
   ```

2. **Open your browser** and navigate to the displayed URL (typically `http://localhost:8501`)

3. **Authenticate with AWS:**
   - Enter your username and password
   - Provide your AWS Account ID
   - Select your preferred AWS region
   - Click "Authenticate"

## 📖 How to Use

### Step 1: Authentication
- Enter your AWS credentials in the sidebar
- Select your AWS region
- Click "Authenticate" to establish connection

### Step 2: Upload Data
- Upload an Excel (.xlsx, .xls) or CSV file
- Preview your data and review column information
- Check basic statistics and data types

### Step 3: Natural Language Query
- Describe what you want to analyze in plain English
- Examples:
  - "Show me the top 5 products by sales amount"
  - "Find the average age by department"
  - "Count how many orders were placed each month"
  - "Which customers have the highest total purchase value?"

### Step 4: Review and Execute
- Review the generated SQL query
- Edit the query if needed
- Click "Execute Query" to run the analysis

### Step 5: Analyze Results
- **Table View**: See results in tabular format
- **Charts**: View automatically generated visualizations
- **Export**: Download results in CSV, Excel, or JSON format

## 📊 Supported Visualizations

The application automatically creates appropriate charts based on your data:

- **Bar Charts**: For categorical vs numeric data
- **Line Charts**: For time series or trend analysis
- **Pie Charts**: For distribution analysis
- **Scatter Plots**: For correlation analysis

## 🔧 Configuration

### AWS Region Support
- us-east-1 (default)
- us-west-2
- eu-west-1
- ap-southeast-1

### Supported File Formats
- Excel (.xlsx, .xls)
- CSV (.csv)

### Export Formats
- CSV (Comma-separated values)
- Excel (.xlsx)
- JSON (JavaScript Object Notation)

## 🔒 Security Features

- Secure credential handling
- Session-based authentication
- No credentials stored persistently
- Proxy support for enterprise environments

## 🛠️ Troubleshooting

### Common Issues

1. **Authentication Fails**
   - Verify username and password
   - Check AWS Account ID format
   - Ensure network connectivity
   - Verify proxy settings if in corporate environment

2. **File Upload Issues**
   - Check file format (Excel/CSV only)
   - Ensure file is not corrupted
   - Try with a smaller file first

3. **SQL Generation Problems**
   - Make your natural language query more specific
   - Ensure uploaded data has clear column names
   - Try simpler queries first

4. **Connection Errors**
   - Check internet connectivity
   - Verify AWS Bedrock service availability in your region
   - Confirm proxy settings

### Performance Tips

- Keep uploaded files under 100MB for optimal performance
- Use specific column names in your queries
- Test with simple queries before complex analysis

## 📚 Example Queries

Here are some example natural language queries you can try:

### Basic Queries
- "Show all records"
- "Count total number of rows"
- "Display unique values in [column_name]"

### Aggregation Queries
- "Find the sum of [column_name] by [category_column]"
- "Calculate average [numeric_column] for each [group_column]"
- "Show maximum and minimum values of [column_name]"

### Filtering Queries
- "Show records where [column_name] is greater than [value]"
- "Find all entries from [specific_date] onwards"
- "Display top 10 records by [column_name]"

### Complex Analysis
- "Compare [metric] across different [categories]"
- "Find trends in [column_name] over time"
- "Identify outliers in [numeric_column]"

## 🤝 Support

For issues or questions:
1. Check the troubleshooting section above
2. Verify all prerequisites are met
3. Ensure AWS credentials are valid
4. Test with sample data first

## 📄 File Structure

```
nlp-sql-app/
├── nlp_sql_app.py          # Main Streamlit application
├── enhanced_aws_login.py   # AWS authentication module
├── requirements.txt        # Python dependencies
└── README.md              # This file
```

## 🔄 Updates and Maintenance

- Keep dependencies updated: `pip install -r requirements.txt --upgrade`
- Update Streamlit regularly: `pip install streamlit --upgrade`
- Monitor AWS Bedrock service updates for new features

## ⚠️ Important Notes

- This application requires active AWS credentials
- AWS Bedrock usage may incur charges based on usage
- Large files may take longer to process
- Internet connection required for AWS services
- Session data is not persisted between browser sessions

---

**Happy Analyzing! 🎉**
'''

# Save README.md
with open('README.md', 'w') as f:
    f.write(readme_content)

print("Additional files created successfully!")
print("3. requirements.txt - Python dependencies")
print("4. README.md - Comprehensive documentation")